from django.shortcuts import render

def index(request):
	return render(request,'index.html')
def single(request):
	return render(request,'single.html')
def about(request):
	return render(request,'about.html')
def discussion_forum(request):
	return render(request,'discussion_forum.html')
def contact(request):
	return render(request,'contact.html')

