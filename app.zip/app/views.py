from django.shortcuts import render, redirect

from . import models

from . models import product
from . forms import ProductForm
from . forms import BiderForm
from app.forms import UserForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect, HttpResponse
from django.urls import reverse
from django.contrib.auth.decorators import login_required

def index(request):
	return render(request,'index.html')
def single(request):
	return render(request,'single.html')
def about(request):
	return render(request,'about.html')
def discussion_forum(request):
	return render(request,'discussion_forum.html')
def contact(request):
	return render(request,'contact.html')

@login_required
def special(request):
	return HttpResponse("You are logged in !")
@login_required
def user_logout(request):
	logout(request)
	return render(request,'index.html')
def register(request):
    registered = False
    if request.method == 'POST':
        user_form = UserForm(data=request.POST)
        
        if user_form.is_valid():
            user = user_form.save()
            user.set_password(user.password)
            user.save()
            registered = True
        else:
            print(user_form.errors)
    else:
        user_form = UserForm()
       
    return render(request,'register.html',
                          {'user_form':user_form,
                           'registered':registered})
def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user:
            if user.is_active:
                login(request,user)
                return render(request,'bid.html')
            else:
                return HttpResponse("Your account was inactive.")
        else:
            print("Someone tried to login and failed.")
            print("They used username: {} and password: {}".format(username,password))
            return HttpResponse("Invalid login details given")
    else:
        return render(request, 'user_login.html')

def products(request):
	return render(request,'products.html')
def list_products(request):
	products = models.product.objects.all()
	return render(request,'products.html',{'products':products})

def create_product(request):
	form = ProductForm(request.POST or None)
	if form.is_valid():
		form.save()
		return redirect('list_products') 
	return render(request,'products-form.html',{'form':form})
def update_product(request,id):
	product = models.product.objects.get(id = id)
	form = ProductForm(request.POST or None,instance = product)
	if form.is_valid():
		form.save()
		return redirect('list_products') 
	return render(request,'products-form.html',{'form':form,'product':product})
def delete_product(request,id):
	product = models.product.objects.get(id = id)
	if request.method == 'POST':
		product.delete()
		return redirect('list_products') 
	return render(request,'product-delete-confirm.html',{'product':product})

def list_bid(request):
	bid_details = models.bider.objects.all()
	bid_details = [(bid.username, bid.price) for bid in bid_details]
	# return render('bid.html',{'bids':bid_details, 'name':'Gautham'})
	return render(request, 'bid.html', {'bids':bid_details})

def bid(request):
	form = BiderForm(request.POST or None)
	print(form)
	if request.method == 'POST':
		username = request.POST['user']
		password = request.POST['password']
		price = request.POST['price']
		user = authenticate(username = username, password = password)
		if user:
			if user.is_active:
				if form:
					bid = models.bider()
					bid.username = username
					bid.price = price
					bid.save()
					return list_bid(request)
			else:
				return render(request, 'user_login.html')		
	return render(request,'user_login.html')		


# 'registered':registered