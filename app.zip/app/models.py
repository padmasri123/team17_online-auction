#/models.py
from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class UserForm(models.Model):
	username = models.CharField(max_length = 50)
	password = models.CharField(max_length = 50)
	email = models.CharField(max_length = 50)

class product(models.Model):
	description = models.CharField(max_length = 500)
	price = models.IntegerField()
	quantity = models.IntegerField()

class bider(models.Model):
	username = models.CharField(max_length = 50)
	price = models.IntegerField()

# def __str__(self):
# 	return self.user.username
# 	return self.description
# 	return self.price
