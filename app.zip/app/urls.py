from django.urls import path
from . import views
from . views import list_products,create_product,update_product,list_bid
app_name = 'app'

urlpatterns = [
	path("", views.index, name='index'),
	path("index", views.index, name='index'),
	path("single", views.single, name='single'),
	path("about", views.about, name='about'),
	path("contact", views.contact, name='contact'),
	path("discussion_forum", views.discussion_forum, name='discussion_forum'),
	path("register", views.register, name='register'),
    	path("user_login", views.user_login, name='user_login'),
	path("user_logout",views.user_logout,name='user_logout'),
	path('',list_products,name = 'list_product'),
	path('new',create_product,name = 'create_product'),
	path('update/<int:id>/',update_product,name = 'update_product'),
	path('products',views.products, name='product'),
	path('bid',views.bid,name='bid'),
	path('',list_bid,name = 'list_bid'),
]



# SET THE NAMESPACE!

# Be careful setting the name to just /login use userlogin instead

