from django.urls import path
from . import views
# app_name = 'app'

urlpatterns = [
	path("", views.index, name='index'),
	path("index", views.index, name='index'),
	path("single", views.single, name='single'),
	path("about", views.about, name='about'),
	path("contact", views.contact, name='contact'),
	path("discussion_forum", views.discussion_forum, name='discussion_forum'),
	path("register", views.register, name='register'),
    	path("user_login", views.user_login, name='user_login'),
]



# SET THE NAMESPACE!

# Be careful setting the name to just /login use userlogin instead

