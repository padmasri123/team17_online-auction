# app/forms.py
from django import forms
from django.contrib.auth.models import User
from . models import product
from . models import bider
class UserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())
    class Meta():
        model = User
        fields = ('username','password','email')
class ProductForm(forms.ModelForm):
	class Meta():
		model = product
		fields = ['description','price','quantity']
class BiderForm(forms.ModelForm):
	class Meta():
		model = bider
		fields = ['username','price']
