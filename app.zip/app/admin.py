# app/admin.py
from django.contrib import admin
from app.models import User
from app.models import product
from app.models import bider
# Register your models here.
admin.site.unregister(User)
admin.site.register(User)
admin.site.register(product)
admin.site.register(bider)
